        <footer>
            <div id="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <ul class="list list-inline">
                                <li><button class="sometimesUp" onclick="scrollToThis('top')"><span class="glyphicon glyphicon-chevron-up" aria-hidden="true" aria-label="Scroll to top"></span></button></li>
                                <li><img src="Images/ASE-Certification-107x41.png">
                                </li>
                                <li><img src="Images/auto-value-logo-113x40.png">
                                </li>
                                <li>
                                    <p>Van Handel Automotive | 127 W Sisters Park Drive | Sisters, OR 97759
                                        <br />
                                        541-549-0416 | Contact Us
                                    </p>
                                </li>
                            
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>         
        
        
        
        
    </body>
</html>