<!DOCTYPE html>
<html>
    <head>
        <title>Van handel Auto</title>
        <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
        
        <link rel="Stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/style.css">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
        <script src="CustomBehaviors.js"></script>
        
        <!-- Place this tag in your head or just before your close body tag. -->
        <script src="https://apis.google.com/js/platform.js" async defer></script>

    </head>
    <body>
        
        <header id="header"> 
            <div id="header-top-global">
                <div class="container">
                    <div class="row">
                        <div class="alert alert-info alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            <strong>Hello!</strong> Just wanted to let you know we do automotive work too!
                        </div>
                    </div>
                </div>
            </div>
            <div id="header-contact">
                <div class="container hidden-sm hidden-xs">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <img src="Images/Screenshot%20(310).png" width="125px;">
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-6">
                            <div class="row">
                                <div class="col-lg-8 col-md-6">
                                    <ul class="list">
                                        <li><a>Work #</a></li>
                                        <li><a>Phone #</a></li>
                                    </ul>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <button id="appointment" style="margin-top: 10px; height: 60px;"><p>make an appointment</p></button>
                                </div>
                            </div>
                            <div class="row">
                                <div class=" col-lg-offset-2 col-lg-10 col-md-10 col-md-offset-2">
                                    <div class="input-group">
                                      <input type="text" class="form-control" placeholder="Search for...">
                                    </div><!-- /input-group -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            <div id="header-nav">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <nav class="navbar navbar-default" role="navigation">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header" style="padding: 10px 0px 10px 0px;">
                                    <a class="navbar-brand" href="#"><h1><b>Van Handel Automotive</b></h1></a>

                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded=" false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span style="margin-top: 10px;" class="icon-bar"></span>
                                        <span style="margin-top: 10px;" class="icon-bar"></span>
                                    </button>
                                </div>

                                <div class="collapse navbar-collapse navbar-default" id="bs-example-navbar-collapse-1">
                                  <ul class="nav navbar-nav">
                                     <li>
                                      <a href="#"><p>Home</p></a>
                                    </li>
                                    <li class="divider-vertical"></li>
                                    <li class="dropdown">
                                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" id="services"><p>services</p></a>
                                      <ul class="dropdown-menu">
                                        <li><a href="#">Link</a></li>
                                        <li role="separator" class="divider"></li>
                                        <li><a href="#">Link</a></li>
                                        <li role="separator" class="divider"></li>
                                        <li><a href="#">Link</a></li>
                                      </ul>
                                    </li>
                                    <li class="divider-vertical"></li>
                                    <li class="dropdown">
                                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" id="LinkAbout"><p>about us</p></a>
                                      <ul class="dropdown-menu">
                                        <li><a href="pages/about.html#AboutCrew">Our Crew</a></li>
                                        <li role="separator" class="divider"></li>
                                        <li><a href="pages/about.html#AboutDescription">Who We Are</a></li>
                                        <li role="separator" class="divider"></li>
                                        <li><a href="pages/about.html#Gallery">Gallery</a></li>
                                      </ul>
                                    </li>
                                    <li class="divider-vertical"></li>
                                    <li>
                                      <a href="#" role="button"><p>directions</p></a>
                                    </li>
                                    <li class="divider-vertical"></li>
                                    <li class="dropdown">
                                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><p>contact us</p></a>
                                      <ul class="dropdown-menu">
                                        <li><a href="#">Link</a></li>
                                        <li role="separator" class="divider"></li>
                                        <li><a href="#">Link</a></li>
                                        <li role="separator" class="divider"></li>
                                        <li><a href="#">Link</a></li>
                                      </ul>
                                    </li>
                                  </ul><!--End nav List-->
                                </div><!-- /.navbar-collapse -->
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div id="carousel">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                          <!-- Indicators -->
                          <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                          </ol>

                          <!-- Wrapper for slides -->
                          <div class="carousel-inner" role="listbox">
                            <div class="item active slide0">
                              <div class="carousel-caption slide-intro-0">
                                    <h2>Welcome to Van Handel Automotive</h2>
                                    <i>The best automotive shop in Sisters</i>
                                    <p>We do automotive work, back massages, tech repair, and plumbin! </p>
                                      <p>Impressed?? We know. But feel free to let us or our competitors  know anytime</p>
                                      <b>-Love, Miles</b>
                                    <ul class="list list-inline">
                                        <li><button id="appointment" style="color: white; font-size: 18px;">Make an Appointment</button></li>
                                        <li><button id="QuoteButton" style=" font-size: 18px;">
                                        Get a FREE repair quote
                                    </button></li>
                                    </ul>
                                </div>
                              </div>
                            <div class="item slide1">
                              <div class="carousel-caption slide-intro-1">
                                  <div id="ShopTimes">
                                    <h2>Business Hours</h2>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="list">
                                            <li>Monday</li>
                                            <li>Tuesday</li>
                                            <li>Wednesday</li>
                                            <li>Thursday</li>
                                            <li>Friday</li>
                                            <li>Sat-Sun</li>
                                        </ul>
                                    </div>
                                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="list">
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>Closed</li>
                                        </ul>
                                    </div>
                                  </div>
                              </div>
                            </div>
                              <div class="item slide2">
                              <div class="carousel-caption">
                              </div>
                            </div>  
                          </div>

                          <!-- Controls -->
                          <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                          </a>
                          <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                          </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    
        <div id="support-bar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>Learn More About Us</h3></a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>Call Us Here</h3></a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>ASE Certifications</h3></a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>The Shop</h3></a>
                    </div>
                </div>
            </div>
        </div>
        
    
        <div id="IntroAbout">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div>
                            <button id="appointment" style="margin-top: 15px;margin-bottom: 10px; "><h3 style="text-decoration: none;">make an appointment</h3></button>
                            
                        </div>
                        <div>
                            <h3>business hours</h3>
                            <h4>Monday - Friday: 8am - 5pm</h4>
                            <h4>Saturday - Sunday: Closed</h4>
                            <p>127 W Sisters Park Drive Sisters, OR 97759</p>
                            <div>
                            <ul class="list hidden-sm hidden-xs">
                                <li class="bold">home</li>
                                <li class="bold">contact us</li>
                                <li>
                                    <ul class="list">
                                        <li>Make An Appointment</li>
                                        <li>Request A Quote</li>                 
                                        <li>Contact Us</li>
                                    </ul>
                                </li>
                                <li class="bold">Directions</li>
                                <li class="bold">services</li>
                                <li>
                                    <ul class="list">
                                        <li>Services Overview</li>
                                        <li>Factory Maintenance</li>
                                        <li> Brakes </li>
                                        <li> Oil Change</li>
                                        <li>Tire Service</li>
                                    </ul>
                                </li>
                                <li class="bold">about</li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="row">
                            <h2 style="border-bottom: 1px solid #000">Who We Are</h2>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nullaLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla  </p>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <img src="Images/IMG_8897.JPG" style="width: 100%;">
                                </div>
                            </div>
                            <br />
                            <hr />
                            <br />
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" style="text-align: right;">
                                    <img src="Images/ASE-Certification-107x41.png" width="100px;">
                                    <img src="Images/auto-value-logo-113x40.png" width="100px;">
                                    <p style="text-align: right;">All our members are ASE Certified and we are a Certified Service Center
                                    </p>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <img src="Images/GoogleReviewsScreenshot.png" width="100%;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <br />
        
        
        <div id="Blog">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h2><i>Blog</i></h2>
                        <h4><i><b>Brought to you by Chad the Lad</b></i></h4>
                    </div>
                </div>
                <br />
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <img height="400px;" width="100%" src="Images/Car%20Dude.jpg">
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="color: white;">
                        <h3 style="border-bottom: 1.5px solid #000; width: 80%;">Car Dudes</h3>
                        <p>I don't think I have seen a greater movie than <i>Dude Where's My Car</i>. What I like most about it is its sofasticated texture and plot. Like, where is <i>THE</i> car?? You just don't know...It's weird ya know. Anyways back to cars and plumbin.</p>
                        <br />
                        <h4>Quote of the Day</h4>
                        <p><q>We will now use the power of the Continuum Transfunctioner to banish you to Hoboken, New Jersey.</q></p>
                    </div>
                </div>
                <br />
                <hr style="border-color: black; width: 80%;" />
            </div>
        </div>
        
        
        <br />
        <hr />
        <br />
        
        <div id="GoogleMaps">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2855.6494262676983!2d-121.55152068405658!3d44.29659807910449!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54bf30b3b8369be5%3A0x49dc8b03645d5527!2sVan+Handel+Automotive+Repair!5e0!3m2!1sen!2sus!4v1513810539878" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>                    </div>
                </div>
            </div>
        </div>
        <footer>
            <div id="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <ul class="list list-inline">
                                <li><button class="sometimesUp" onclick="scrollToThis('top')"><span class="glyphicon glyphicon-chevron-up" aria-hidden="true" aria-label="Scroll to top"></span></button></li>
                                <li><img src="Images/ASE-Certification-107x41.png">
                                </li>
                                <li><img src="Images/auto-value-logo-113x40.png">
                                </li>
                                <li>
                                    <p>Van Handel Automotive | 127 W Sisters Park Drive | Sisters, OR 97759
                                        <br />
                                        541-549-0416 | Contact Us
                                    </p>
                                </li>
                            
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>         
        
        
        
        
    </body>
</html>
