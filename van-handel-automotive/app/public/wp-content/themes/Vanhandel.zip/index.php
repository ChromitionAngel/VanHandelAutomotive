<?php get_header(); ?>
<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="post-header">
       <div class="date"><?php the_time( 'M j y' ); ?></div>
       <h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
       <div class="author"><?php the_author(); ?></div>
    </div><!--end post header-->
    <div class="entry clear">
       <?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
       <?php the_content(); ?>
       <?php edit_post_link(); ?>
       <?php wp_link_pages(); ?> </div>
    <!--end entry-->
    <div class="post-footer">
       <div class="comments"><?php comments_popup_link( 'Leave a Comment', '1 Comment', '% Comments' ); ?></div>
    </div><!--end post footer-->
    </div><!--end post-->
<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
    <div class="navigation index">
       <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
       <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
    </div><!--end navigation-->
<?php else : ?>
<?php endif; ?>


        <div id="carousel">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                          <!-- Indicators -->
                          <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                          </ol>

                          <!-- Wrapper for slides -->
                          <div class="carousel-inner" role="listbox">
                            <div class="item active slide0">
                              <div class="carousel-caption slide-intro-0">
                                    <h2>Welcome to Van Handel Automotive</h2>
                                    <i>The best automotive shop in Sisters</i>
                                    <p>We do automotive work, back massages, tech repair, and plumbin! </p>
                                      <p>Impressed?? We know. But feel free to let us or our competitors  know anytime</p>
                                      <b>-Love, Miles</b>
                                    <ul class="list list-inline">
                                        <li><button id="appointment" style="color: white; font-size: 18px;">Make an Appointment</button></li>
                                        <li><button id="QuoteButton" style=" font-size: 18px;">
                                        Get a FREE repair quote
                                    </button></li>
                                    </ul>
                                </div>
                              </div>
                            <div class="item slide1">
                              <div class="carousel-caption slide-intro-1">
                                  <div id="ShopTimes">
                                    <h2>Business Hours</h2>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="list">
                                            <li>Monday</li>
                                            <li>Tuesday</li>
                                            <li>Wednesday</li>
                                            <li>Thursday</li>
                                            <li>Friday</li>
                                            <li>Sat-Sun</li>
                                        </ul>
                                    </div>
                                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="list">
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>8am - 5pm</li>
                                            <li>Closed</li>
                                        </ul>
                                    </div>
                                  </div>
                              </div>
                            </div>
                              <div class="item slide2">
                              <div class="carousel-caption">
                              </div>
                            </div>  
                          </div>

                          <!-- Controls -->
                          <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                          </a>
                          <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                          </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    
        <div id="support-bar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>Learn More About Us</h3></a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>Call Us Here</h3></a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>ASE Certifications</h3></a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="#"><h3>The Shop</h3></a>
                    </div>
                </div>
            </div>
        </div>
        
    
        <div id="IntroAbout">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div>
                            <button id="appointment" style="margin-top: 15px;margin-bottom: 10px; "><h3 style="text-decoration: none;">make an appointment</h3></button>
                            
                        </div>
                        <div>
                            <h3>business hours</h3>
                            <h4>Monday - Friday: 8am - 5pm</h4>
                            <h4>Saturday - Sunday: Closed</h4>
                            <p>127 W Sisters Park Drive Sisters, OR 97759</p>
                            <div>
                            <ul class="list hidden-sm hidden-xs">
                                <li class="bold">home</li>
                                <li class="bold">contact us</li>
                                <li>
                                    <ul class="list">
                                        <li>Make An Appointment</li>
                                        <li>Request A Quote</li>                 
                                        <li>Contact Us</li>
                                    </ul>
                                </li>
                                <li class="bold">Directions</li>
                                <li class="bold">services</li>
                                <li>
                                    <ul class="list">
                                        <li>Services Overview</li>
                                        <li>Factory Maintenance</li>
                                        <li> Brakes </li>
                                        <li> Oil Change</li>
                                        <li>Tire Service</li>
                                    </ul>
                                </li>
                                <li class="bold">about</li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="row">
                            <h2 style="border-bottom: 1px solid #000">Who We Are</h2>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nullaLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla  </p>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <img src="Images/IMG_8897.JPG" style="width: 100%;">
                                </div>
                            </div>
                            <br />
                            <hr />
                            <br />
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" style="text-align: right;">
                                    <img src="Images/ASE-Certification-107x41.png" width="100px;">
                                    <img src="Images/auto-value-logo-113x40.png" width="100px;">
                                    <p style="text-align: right;">All our members are ASE Certified and we are a Certified Service Center
                                    </p>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <img src="Images/GoogleReviewsScreenshot.png" width="100%;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <br />
        
        
        <div id="Blog">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h2><i>Blog</i></h2>
                        <h4><i><b>Brought to you by Chad the Lad</b></i></h4>
                    </div>
                </div>
                <br />
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <img height="400px;" width="100%" src="Images/Car%20Dude.jpg">
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="color: white;">
                        <h3 style="border-bottom: 1.5px solid #000; width: 80%;">Car Dudes</h3>
                        <p>I don't think I have seen a greater movie than <i>Dude Where's My Car</i>. What I like most about it is its sofasticated texture and plot. Like, where is <i>THE</i> car?? You just don't know...It's weird ya know. Anyways back to cars and plumbin.</p>
                        <br />
                        <h4>Quote of the Day</h4>
                        <p><q>We will now use the power of the Continuum Transfunctioner to banish you to Hoboken, New Jersey.</q></p>
                    </div>
                </div>
                <br />
                <hr style="border-color: black; width: 80%;" />
            </div>
        </div>
        
        
        <br />
        <hr />
        <br />
        
        <div id="GoogleMaps">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2855.6494262676983!2d-121.55152068405658!3d44.29659807910449!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54bf30b3b8369be5%3A0x49dc8b03645d5527!2sVan+Handel+Automotive+Repair!5e0!3m2!1sen!2sus!4v1513810539878" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>                    </div>
                </div>
            </div>
        </div>
<?php get_footer(); ?>
